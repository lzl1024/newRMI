package util;

public class Constants {
    public static final int MAX_PORT_NUM = 65535;
    public static final String CLASS_PREFIX = "interfaces/";
    public static final String S3_URL = "http://s3.amazonaws.com/zhuolinl-640/";
}
